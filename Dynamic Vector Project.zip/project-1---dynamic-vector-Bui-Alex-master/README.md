# project-1---dynamic-vector

My submission for CPSC 131, Section 07, Lab Week 3

# My Information

* Name: Alex Bui
* CWID: 885680090
* Email: buia4@csu.fullerton.edu
