
/**
 * You don't have to modify this source file, but can if you want.
 * This will not be used for grading, so you can use it to debug your
 * vector class.
 * This is the program that runs with "make run"
 */

///	Your welcome
#include <iostream>
#include "MyVector.hpp"

///	Your welcome
using std::cout, std::endl;

//
int main()
{
	//
	cout << "Hello! Maybe use this source file for debugging?" << endl;

	MyVector <int> v = 5; 
	cout << v.capacity() << endl;


	 v.insert(0, 2);
	 cout << v.at(0) << endl;
	// // v.push_back(5);
	// // cout <<"Capacity Size Original: " <<  v.capacity() << endl;
	// // v.reserve(85);
	// // cout <<"New capacity size: " << v.capacity() << endl;
	//  for(int i = 0; i < v.size(); i++){
	// 	cout << i << " : " << v[i]<< endl;
	//  }

	// cout <<"Size of Vector: " << v.size() << endl;
	// // v.pop_back();
	// cout << "Pop_back function, should remove last elemnt of array" << endl;
	
	//  for(int i = 0; i < v.size(); i++){
	//  	cout << i << " : " << v[i]<< endl;
	//  }
	
	// 	cout << "Current Capcity: " << v.capacity() << endl;
	//   v.erase(0);
	//  v.insert(1,9);
	// cout << "Second Array:" << endl;
	// for(int i = 0; i < v.size(); i++){
	// 	cout << i << " : " << v[i]<< endl;
	// }

	// v.pop_back();
	//   v.clear();
	//  cout << "array that's popped the last element" << endl; 
	// 	for(int i = 0; i < v.size(); i++){
	// 		cout << v[i] << endl;
	// 	}
	// cout <<"Current Capacity: " <<  v.capacity() << endl;
	// // v.clear();
	// v.empty();
	// cout << v.empty() << endl;
	// cout <<"Current Capacity after empty: " <<  v.capacity() << endl;
	
	return 0;
}


